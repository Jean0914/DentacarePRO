import SwiftUI

struct LoginView: View {
    @EnvironmentObject var store: DataStore
    @State private var tab = 0
    @State private var email = ""
    @State private var password = ""
    @State private var error = ""
    @State private var regName = ""
    @State private var regEmail = ""
    @State private var regPassword = ""
    @State private var regConfirm = ""
    @State private var regError = ""

    var body: some View {
        ZStack {
            LinearGradient(colors: [AppColor.sidebar, AppColor.primaryDark, AppColor.primary],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            ScrollView {
                VStack(spacing: 0) {
                    VStack(spacing: 6) {
                        Text("🦷").font(.system(size: 52))
                        Text("DentaCare Pro").font(.title2.weight(.heavy)).foregroundStyle(.white)
                        Text("Sistema de Gestión Dental").font(.subheadline).foregroundStyle(Color(hex: "BAE6FD"))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 28)
                    .background(LinearGradient(colors: [AppColor.sidebar, AppColor.primaryDark], startPoint: .leading, endPoint: .trailing))

                    Picker("", selection: $tab) {
                        Text("Iniciar Sesión").tag(0)
                        Text("Registrarse").tag(1)
                    }
                    .pickerStyle(.segmented)
                    .padding([.horizontal, .top], 20)

                    VStack(alignment: .leading, spacing: 14) {
                        if tab == 0 { loginForm } else { registerForm }
                    }
                    .padding(20)
                }
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 20))
                .shadow(color: .black.opacity(0.25), radius: 24, y: 12)
                .padding(20)
                .frame(maxWidth: 460)
                .frame(maxWidth: .infinity)
            }
        }
    }

    private func field(_ title: String, text: Binding<String>, placeholder: String, secure: Bool = false, email: Bool = false) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.footnote.weight(.semibold)).foregroundStyle(AppColor.textMuted)
            Group {
                if secure { SecureField(placeholder, text: text) }
                else { TextField(placeholder, text: text).keyboardType(email ? .emailAddress : .default) }
            }
            .textInputAutocapitalization((email || secure) ? TextInputAutocapitalization.never : TextInputAutocapitalization.words)
            .autocorrectionDisabled()
            .padding(12)
            .overlay(RoundedRectangle(cornerRadius: 8).stroke(AppColor.border))
        }
    }

    private var loginForm: some View {
        VStack(alignment: .leading, spacing: 14) {
            field("Correo electrónico", text: $email, placeholder: "tu@correo.com", email: true)
            field("Contraseña", text: $password, placeholder: "••••••••", secure: true)
            if !error.isEmpty { Text("⚠ \(error)").font(.footnote).foregroundStyle(AppColor.danger) }
            Button {
                if !store.login(email: email, password: password) { error = "Correo o contraseña incorrectos." }
            } label: {
                Text("Ingresar al Sistema").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 12)
                    .background(AppColor.primary).foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius: 10))
            }
            VStack(alignment: .leading, spacing: 4) {
                Text("Demo:").bold()
                Text("🩺 Dentista: dentista@clinica.mx / 1234")
                Text("👤 Paciente: maria.garcia@email.com / 1234")
            }
            .font(.caption)
            .foregroundStyle(AppColor.primaryDark)
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(AppColor.primaryLight)
            .clipShape(RoundedRectangle(cornerRadius: 10))
        }
    }

    private var registerForm: some View {
        VStack(alignment: .leading, spacing: 14) {
            field("Nombre completo", text: $regName, placeholder: "Tu nombre")
            field("Correo electrónico", text: $regEmail, placeholder: "tu@correo.com", email: true)
            field("Contraseña", text: $regPassword, placeholder: "Mínimo 6 caracteres", secure: true)
            field("Confirmar contraseña", text: $regConfirm, placeholder: "Repite la contraseña", secure: true)
            if !regError.isEmpty { Text("⚠ \(regError)").font(.footnote).foregroundStyle(AppColor.danger) }
            Button {
                if let e = store.register(name: regName, email: regEmail, password: regPassword, confirm: regConfirm) { regError = e }
            } label: {
                Text("Crear Cuenta").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 12)
                    .background(AppColor.primary).foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius: 10))
            }
        }
    }
}
