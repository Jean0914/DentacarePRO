import SwiftUI

struct PatientPortalView: View {
    @EnvironmentObject var store: DataStore
    let user: AppUser

    private var patient: Patient? {
        store.patients.first { $0.id == user.patientId || $0.email == user.email }
    }

    var body: some View {
        if let patient {
            TabView {
                PortalHome(patient: patient)
                    .tabItem { Label("Mi Panel", systemImage: "house") }
                PortalAppointments(patient: patient)
                    .tabItem { Label("Mis Citas", systemImage: "calendar") }
                PortalClinical(patient: patient)
                    .tabItem { Label("Historial", systemImage: "list.clipboard") }
                PortalImages(patient: patient)
                    .tabItem { Label("Imágenes", systemImage: "photo.on.rectangle") }
                PortalPayments(patient: patient)
                    .tabItem { Label("Pagos", systemImage: "dollarsign.circle") }
            }
        } else {
            NavigationStack {
                VStack(spacing: 12) {
                    Text("👤").font(.system(size: 52))
                    Text("Perfil no encontrado").font(.title2.bold())
                    Text("Tu cuenta de paciente aún no tiene un expediente médico. Contacta a la clínica.")
                        .multilineTextAlignment(.center).foregroundStyle(AppColor.textMuted)
                }
                .padding(32)
                .frame(maxHeight: .infinity)
                .screenBackground()
                .toolbar { ToolbarItem(placement: .topBarTrailing) { UserMenu() } }
            }
        }
    }
}

struct PortalHome: View {
    @EnvironmentObject var store: DataStore
    let patient: Patient
    @State private var showBook = false

    var body: some View {
        let today = Fmt.todayString
        let apts = store.appointments.filter { $0.patientId == patient.id }
        let upcoming = apts.filter { $0.date >= today && $0.status != "Cancelada" && $0.status != "Finalizada" }.sorted { $0.date < $1.date }
        let recs = store.records.filter { $0.patientId == patient.id }
        let paid = store.payments.filter { $0.patientId == patient.id }.reduce(0) { $0 + $1.amount }

        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("¡Hola, \(patient.name.split(separator: " ").first.map(String.init) ?? patient.name)! 👋")
                            .font(.title2.weight(.heavy))
                        Text("Bienvenido(a) a tu portal dental").opacity(0.85)
                    }
                    .foregroundStyle(.white)
                    .padding(22).frame(maxWidth: .infinity, alignment: .leading)
                    .background(LinearGradient(colors: [AppColor.sidebar, AppColor.primaryDark], startPoint: .leading, endPoint: .trailing))
                    .clipShape(RoundedRectangle(cornerRadius: 16))

                    StatGrid {
                        StatCard(label: "Citas Totales", value: "\(apts.count)", icon: "📅", color: AppColor.primary)
                        StatCard(label: "Próx. Citas", value: "\(upcoming.count)", icon: "⏰", color: AppColor.warning)
                        StatCard(label: "Entradas Clínicas", value: "\(recs.count)", icon: "📋", color: AppColor.secondary)
                        StatCard(label: "Total Pagado", value: Fmt.money(paid), icon: "💰", color: AppColor.success)
                    }

                    if !upcoming.isEmpty {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Próximas Citas").font(.headline)
                            ForEach(upcoming.prefix(3)) { a in
                                HStack {
                                    VStack(alignment: .leading) {
                                        Text(store.treatment(a.treatmentId)?.name ?? "Consulta").fontWeight(.semibold)
                                        Text("\(a.dentist) · \(a.time)").font(.footnote).foregroundStyle(AppColor.textMuted)
                                    }
                                    Spacer()
                                    VStack(alignment: .trailing, spacing: 4) {
                                        Text(Fmt.date(a.date)).fontWeight(.bold).foregroundStyle(AppColor.primary)
                                        Badge(label: a.status)
                                    }
                                }
                                Divider()
                            }
                        }
                        .padding(16).frame(maxWidth: .infinity, alignment: .leading).cardBackground()
                    }

                    Button { showBook = true } label: {
                        Text("📅 Agendar Nueva Cita").font(.headline).padding(.horizontal, 20).padding(.vertical, 12)
                            .background(AppColor.primary).foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                }
                .padding(16)
            }
            .screenBackground()
            .navigationTitle("Mi Panel")
            .toolbar { ToolbarItem(placement: .topBarTrailing) { UserMenu() } }
            .sheet(isPresented: $showBook) { BookAppointmentSheet(patient: patient) }
        }
    }
}

struct PortalAppointments: View {
    @EnvironmentObject var store: DataStore
    let patient: Patient
    @State private var showBook = false

    var body: some View {
        let apts = store.appointments.filter { $0.patientId == patient.id }.sorted { $0.date > $1.date }
        NavigationStack {
            ScrollView {
                VStack(spacing: 12) {
                    if apts.isEmpty { EmptyCard(icon: "📅", text: "Sin citas registradas") }
                    ForEach(apts) { a in
                        let t = store.treatment(a.treatmentId)
                        HStack(alignment: .top) {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(t?.name ?? "Consulta").font(.headline)
                                Text("\(a.dentist) · \(a.time) hrs").font(.footnote).foregroundStyle(AppColor.textMuted)
                                if !a.notes.isEmpty { Text(a.notes).font(.caption).foregroundStyle(AppColor.textLight) }
                            }
                            Spacer()
                            VStack(alignment: .trailing, spacing: 4) {
                                Text(Fmt.date(a.date)).fontWeight(.semibold)
                                Badge(label: a.status)
                                if let t { Text(Fmt.money(t.price)).font(.caption).foregroundStyle(AppColor.textLight) }
                            }
                        }
                        .padding(14).cardBackground()
                    }
                }
                .padding(16)
            }
            .screenBackground()
            .navigationTitle("Mis Citas")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button { showBook = true } label: { Label("Agendar", systemImage: "plus") } }
                ToolbarItem(placement: .topBarTrailing) { UserMenu() }
            }
            .sheet(isPresented: $showBook) { BookAppointmentSheet(patient: patient) }
        }
    }
}

struct PortalClinical: View {
    @EnvironmentObject var store: DataStore
    let patient: Patient
    var body: some View {
        let recs = store.records.filter { $0.patientId == patient.id }.sorted { $0.date > $1.date }
        NavigationStack {
            ScrollView {
                VStack(spacing: 12) {
                    if recs.isEmpty { EmptyCard(icon: "📋", text: "Sin registros clínicos aún") }
                    ForEach(recs) { ClinicalRecordCard(record: $0, showDentist: false) }
                }
                .padding(16)
            }
            .screenBackground()
            .navigationTitle("Mi Historial")
            .toolbar { ToolbarItem(placement: .topBarTrailing) { UserMenu() } }
        }
    }
}

struct PortalImages: View {
    @EnvironmentObject var store: DataStore
    let patient: Patient
    var body: some View {
        let imgs = store.images.filter { $0.patientId == patient.id }
        NavigationStack {
            ScrollView {
                if imgs.isEmpty {
                    EmptyCard(icon: "🔬", text: "Sin imágenes registradas").padding(16)
                } else {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 160), spacing: 12)], spacing: 12) {
                        ForEach(imgs) { ImageCard(image: $0) }
                    }
                    .padding(16)
                }
            }
            .screenBackground()
            .navigationTitle("Mis Imágenes")
            .toolbar { ToolbarItem(placement: .topBarTrailing) { UserMenu() } }
        }
    }
}

struct PortalPayments: View {
    @EnvironmentObject var store: DataStore
    let patient: Patient
    var body: some View {
        let pays = store.payments.filter { $0.patientId == patient.id }
        let total = pays.reduce(0) { $0 + $1.amount }
        NavigationStack {
            ScrollView {
                VStack(spacing: 12) {
                    if pays.isEmpty { EmptyCard(icon: "💰", text: "Sin pagos registrados") }
                    ForEach(Array(pays.reversed())) { p in
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(p.treatmentName).fontWeight(.semibold)
                                HStack {
                                    Badge(label: p.method, color: Color(hex: "065F46"), bg: Color(hex: "F0FDF4"))
                                    Text(Fmt.date(p.date)).font(.footnote).foregroundStyle(AppColor.textMuted)
                                }
                            }
                            Spacer()
                            Text(Fmt.money(p.amount)).fontWeight(.bold).foregroundStyle(AppColor.success)
                        }
                        .padding(14).cardBackground()
                    }
                    HStack {
                        Spacer()
                        Text("Total pagado: ").fontWeight(.bold)
                        Text(Fmt.money(total)).font(.title3.weight(.heavy)).foregroundStyle(AppColor.success)
                    }
                    .padding(16).background(AppColor.surfaceAlt).clipShape(RoundedRectangle(cornerRadius: 10))
                }
                .padding(16)
            }
            .screenBackground()
            .navigationTitle("Mis Pagos")
            .toolbar { ToolbarItem(placement: .topBarTrailing) { UserMenu() } }
        }
    }
}

struct BookAppointmentSheet: View {
    @EnvironmentObject var store: DataStore
    @Environment(\.dismiss) private var dismiss
    let patient: Patient
    @State private var treatmentId = ""
    @State private var date = Date()
    @State private var time = Fmt.toTime("09:00")
    @State private var notes = ""
    @State private var alert: ErrorAlert?
    @State private var done = false

    var body: some View {
        NavigationStack {
            Form {
                Picker("Tratamiento *", selection: $treatmentId) {
                    Text("Seleccionar tratamiento...").tag("")
                    ForEach(store.treatments) { Text("\($0.name) — \(Fmt.money($0.price))").tag($0.id) }
                }
                DatePicker("Fecha preferida *", selection: $date, in: Date()..., displayedComponents: .date)
                DatePicker("Hora preferida", selection: $time, displayedComponents: .hourAndMinute)
                Section("Notas o síntomas") {
                    TextField("Describe brevemente el motivo de tu cita...", text: $notes, axis: .vertical).lineLimit(3...6)
                }
            }
            .navigationTitle("Agendar Cita")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Solicitar Cita") { book() } }
            }
            .alert(item: $alert) { Alert(title: Text("Atención"), message: Text($0.message)) }
            .alert("¡Cita agendada exitosamente!", isPresented: $done) {
                Button("OK") { dismiss() }
            } message: { Text("El equipo de la clínica la confirmará pronto.") }
        }
    }

    private func book() {
        if treatmentId.isEmpty { alert = ErrorAlert(message: "Selecciona tratamiento y fecha."); return }
        store.appointments.append(Appointment(id: DataStore.newId(), patientId: patient.id, treatmentId: treatmentId,
                                              date: Fmt.isoFormatter.string(from: date), time: Fmt.timeFormatter.string(from: time),
                                              status: "Pendiente", notes: notes, dentist: "Dr. González"))
        done = true
    }
}
