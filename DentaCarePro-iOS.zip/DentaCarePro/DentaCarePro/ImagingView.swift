import SwiftUI
import PhotosUI

struct ImageThumb: View {
    @EnvironmentObject var store: DataStore
    let image: DentalImage
    var height: CGFloat = 140
    var body: some View {
        Color(hex: "F1F5F9")
            .frame(height: height)
            .overlay {
                if let ui = store.uiImage(for: image) {
                    Image(uiImage: ui).resizable().scaledToFill()
                } else {
                    Text("🦷").font(.system(size: 44))
                }
            }
            .clipped()
    }
}

struct ImageCard: View {
    let image: DentalImage
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ImageThumb(image: image)
            VStack(alignment: .leading, spacing: 2) {
                Text(image.type).font(.footnote.weight(.semibold)).foregroundStyle(AppColor.text)
                Text(image.description).font(.caption).foregroundStyle(AppColor.textMuted).lineLimit(2)
                Text(Fmt.date(image.date)).font(.caption2).foregroundStyle(AppColor.textLight)
            }
            .padding(10)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppColor.border))
    }
}

struct ImagingView: View {
    @EnvironmentObject var store: DataStore
    @State private var search = ""

    private var filtered: [Patient] {
        search.isEmpty ? store.patients : store.patients.filter { $0.name.lowercased().contains(search.lowercased()) }
    }

    var body: some View {
        NavigationStack {
            List(filtered) { p in
                NavigationLink(value: p.id) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(p.name).font(.headline)
                        Text("\(store.images.filter { $0.patientId == p.id }.count) imágenes")
                            .font(.caption).foregroundStyle(AppColor.textLight)
                    }
                }
            }
            .searchable(text: $search, prompt: "Buscar paciente")
            .scrollContentBackground(.hidden)
            .screenBackground()
            .navigationTitle("Imagenología")
            .toolbar { ToolbarItem(placement: .topBarTrailing) { UserMenu() } }
            .navigationDestination(for: String.self) { id in ImagingDetailView(patientId: id) }
        }
    }
}

struct ImagingDetailView: View {
    @EnvironmentObject var store: DataStore
    let patientId: String
    @State private var showUpload = false
    @State private var viewing: DentalImage?

    var body: some View {
        let imgs = store.images.filter { $0.patientId == patientId }.sorted { $0.date > $1.date }
        ScrollView {
            if imgs.isEmpty {
                EmptyCard(icon: "🔬", text: "Sin imágenes registradas").padding(16)
            } else {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 160), spacing: 12)], spacing: 12) {
                    ForEach(imgs) { img in
                        Button { viewing = img } label: { ImageCard(image: img) }.buttonStyle(.plain)
                    }
                }
                .padding(16)
            }
        }
        .screenBackground()
        .navigationTitle("\(store.patient(patientId)?.name ?? "Paciente") — Imágenes")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { showUpload = true } label: { Label("Subir imagen", systemImage: "plus") }
            }
        }
        .sheet(isPresented: $showUpload) { ImageUploadSheet(patientId: patientId) }
        .sheet(item: $viewing) { img in ImageViewerSheet(image: img) }
    }
}

struct ImageUploadSheet: View {
    @EnvironmentObject var store: DataStore
    @Environment(\.dismiss) private var dismiss
    let patientId: String
    @State private var type = "Radiografía"
    @State private var description = ""
    @State private var pickerItem: PhotosPickerItem?
    @State private var data: Data?
    @State private var alert: ErrorAlert?

    var body: some View {
        NavigationStack {
            Form {
                Picker("Tipo de imagen", selection: $type) {
                    ForEach(Catalog.imageTypes, id: \.self) { Text($0).tag($0) }
                }
                TextField("Descripción (Ej: Radiografía periapical pieza 26)", text: $description, axis: .vertical)
                Section("Archivo de imagen") {
                    PhotosPicker(selection: $pickerItem, matching: .images) {
                        Label(data == nil ? "Elegir de la fototeca" : "Cambiar imagen", systemImage: "photo")
                    }
                    if let data, let ui = UIImage(data: data) {
                        Image(uiImage: ui).resizable().scaledToFit().frame(maxHeight: 220)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                    }
                }
            }
            .navigationTitle("Subir Imagen Dental")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Guardar") { save() } }
            }
            .onChange(of: pickerItem) { _, item in
                guard let item else { return }
                Task {
                    if let d = try? await item.loadTransferable(type: Data.self) { data = d }
                }
            }
            .alert(item: $alert) { Alert(title: Text("Atención"), message: Text($0.message)) }
        }
    }

    private func save() {
        let desc = description.trimmingCharacters(in: .whitespaces)
        if data == nil && desc.isEmpty { alert = ErrorAlert(message: "Adjunta una imagen o agrega descripción."); return }
        if let data { store.addImage(data: data, patientId: patientId, type: type, description: desc) }
        else { store.addImageWithoutFile(patientId: patientId, type: type, description: desc) }
        dismiss()
    }
}

struct ImageViewerSheet: View {
    @EnvironmentObject var store: DataStore
    @Environment(\.dismiss) private var dismiss
    let image: DentalImage
    @State private var confirmDelete = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    if let ui = store.uiImage(for: image) {
                        Image(uiImage: ui).resizable().scaledToFit().clipShape(RoundedRectangle(cornerRadius: 8))
                    } else {
                        ImageThumb(image: image, height: 240).clipShape(RoundedRectangle(cornerRadius: 8))
                    }
                    Text(image.description)
                    Button(role: .destructive) { confirmDelete = true } label: { Label("Eliminar", systemImage: "trash") }
                        .buttonStyle(.borderedProminent).tint(AppColor.danger)
                }
                .padding(16)
            }
            .navigationTitle("\(image.type) — \(Fmt.date(image.date))")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Cerrar") { dismiss() } } }
            .alert("¿Eliminar imagen?", isPresented: $confirmDelete) {
                Button("Cancelar", role: .cancel) {}
                Button("Eliminar", role: .destructive) { store.deleteImage(image); dismiss() }
            }
        }
    }
}
