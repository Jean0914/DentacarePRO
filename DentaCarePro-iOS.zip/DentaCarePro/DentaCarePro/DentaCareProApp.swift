import SwiftUI

@main
struct DentaCareProApp: App {
    @StateObject private var store = DataStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
        }
    }
}

struct RootView: View {
    @EnvironmentObject var store: DataStore

    var body: some View {
        Group {
            if let user = store.currentUser {
                if user.isAdmin {
                    AdminRootView()
                } else {
                    PatientPortalView(user: user)
                }
            } else {
                LoginView()
            }
        }
        .tint(AppColor.primary)
    }
}

/// Menú de usuario (nombre + cerrar sesión) para las barras de navegación.
struct UserMenu: View {
    @EnvironmentObject var store: DataStore
    var body: some View {
        Menu {
            if let u = store.currentUser {
                Text(u.name)
                Text(u.isAdmin ? "Administrador" : "Paciente")
            }
            Button(role: .destructive) { store.logout() } label: {
                Label("Cerrar sesión", systemImage: "rectangle.portrait.and.arrow.right")
            }
        } label: {
            Image(systemName: "person.crop.circle")
        }
    }
}

struct AdminRootView: View {
    @EnvironmentObject var store: DataStore

    var body: some View {
        TabView(selection: $store.adminTab) {
            DashboardView()
                .tabItem { Label("Dashboard", systemImage: "house") }
                .tag(AdminTab.dashboard)
            PatientsView()
                .tabItem { Label("Pacientes", systemImage: "person.2") }
                .tag(AdminTab.patients)
            AppointmentsView()
                .tabItem { Label("Citas", systemImage: "calendar") }
                .tag(AdminTab.appointments)
            ClinicalView()
                .tabItem { Label("Historial", systemImage: "list.clipboard") }
                .tag(AdminTab.clinical)
            ImagingView()
                .tabItem { Label("Imagenología", systemImage: "photo.on.rectangle") }
                .tag(AdminTab.imaging)
            FinanceView()
                .tabItem { Label("Finanzas", systemImage: "dollarsign.circle") }
                .tag(AdminTab.finance)
            TreatmentsView()
                .tabItem { Label("Tratamientos", systemImage: "cross.case") }
                .tag(AdminTab.treatments)
        }
    }
}
