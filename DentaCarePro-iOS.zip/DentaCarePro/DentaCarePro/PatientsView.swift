import SwiftUI

struct PatientsView: View {
    @EnvironmentObject var store: DataStore
    @State private var search = ""
    @State private var editing: Patient?
    @State private var toDelete: Patient?

    private var filtered: [Patient] {
        let q = search.lowercased()
        if q.isEmpty { return store.patients }
        return store.patients.filter {
            $0.name.lowercased().contains(q) || $0.phone.contains(search) || $0.email.lowercased().contains(q)
        }
    }

    private func newPatient() -> Patient {
        Patient(id: DataStore.newId(), name: "", age: 0, phone: "", email: "", address: "", sex: "M",
                bloodType: "O+", allergies: "Ninguna", diseases: "Ninguna", createdAt: Fmt.todayString)
    }

    var body: some View {
        NavigationStack {
            List {
                if filtered.isEmpty { Text("Sin resultados").foregroundStyle(AppColor.textMuted) }
                ForEach(filtered) { p in
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text(p.name).font(.headline)
                            Spacer()
                            Badge(label: p.bloodType, color: Color(hex: "92400E"), bg: Color(hex: "FEF3C7"))
                        }
                        Text("\(p.age) años · \(p.sex == "M" ? "♂" : p.sex == "F" ? "♀" : "⚧") · \(p.phone)")
                            .font(.subheadline).foregroundStyle(AppColor.textMuted)
                        if !p.email.isEmpty { Text(p.email).font(.footnote).foregroundStyle(AppColor.textMuted) }
                        if !p.address.isEmpty { Text(p.address).font(.caption).foregroundStyle(AppColor.textLight) }
                        Text("Creado: \(Fmt.date(p.createdAt))").font(.caption2).foregroundStyle(AppColor.textLight)
                        HStack(spacing: 10) {
                            Button("📋 Historial") { store.openClinical(for: p.id) }
                                .buttonStyle(.bordered)
                            Button("✏️ Editar") { editing = p }
                                .buttonStyle(.bordered)
                            Button("🗑️") { toDelete = p }
                                .buttonStyle(.bordered).tint(AppColor.danger)
                        }
                        .font(.footnote)
                    }
                    .padding(.vertical, 4)
                }
            }
            .searchable(text: $search, prompt: "Buscar por nombre, teléfono o correo")
            .scrollContentBackground(.hidden)
            .screenBackground()
            .navigationTitle("Pacientes")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { editing = newPatient() } label: { Label("Nuevo", systemImage: "plus") }
                }
                ToolbarItem(placement: .topBarTrailing) { UserMenu() }
            }
            .sheet(item: $editing) { p in
                PatientFormSheet(patient: p, isNew: !store.patients.contains(where: { $0.id == p.id }))
            }
            .alert("Confirmar eliminación", isPresented: Binding(get: { toDelete != nil }, set: { if !$0 { toDelete = nil } })) {
                Button("Cancelar", role: .cancel) { toDelete = nil }
                Button("Eliminar", role: .destructive) {
                    if let p = toDelete { store.patients.removeAll { $0.id == p.id } }
                    toDelete = nil
                }
            } message: {
                Text("¿Eliminar al paciente \(toDelete?.name ?? "")? Esta acción no se puede deshacer.")
            }
        }
    }
}

struct PatientFormSheet: View {
    @EnvironmentObject var store: DataStore
    @Environment(\.dismiss) private var dismiss
    @State var patient: Patient
    let isNew: Bool
    @State private var ageText = ""
    @State private var alert: ErrorAlert?

    var body: some View {
        NavigationStack {
            Form {
                Section("Datos personales") {
                    TextField("Nombre completo *", text: $patient.name)
                    TextField("Edad", text: $ageText).keyboardType(.numberPad)
                    TextField("Teléfono *", text: $patient.phone).keyboardType(.phonePad)
                    TextField("Correo", text: $patient.email)
                        .keyboardType(.emailAddress).textInputAutocapitalization(.never).autocorrectionDisabled()
                    Picker("Sexo", selection: $patient.sex) {
                        ForEach(Catalog.sexes, id: \.0) { Text($0.1).tag($0.0) }
                    }
                    Picker("Tipo de sangre", selection: $patient.bloodType) {
                        ForEach(Catalog.bloodTypes, id: \.self) { Text($0).tag($0) }
                    }
                    TextField("Dirección", text: $patient.address)
                }
                Section("Datos médicos") {
                    TextField("Alergias", text: $patient.allergies)
                    TextField("Enfermedades previas", text: $patient.diseases)
                }
            }
            .navigationTitle(isNew ? "Nuevo Paciente" : "Editar Paciente")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Guardar") { save() } }
            }
            .onAppear { ageText = patient.age > 0 ? String(patient.age) : "" }
            .alert(item: $alert) { Alert(title: Text("Atención"), message: Text($0.message)) }
        }
    }

    private func save() {
        let name = patient.name.trimmingCharacters(in: .whitespaces)
        let phone = patient.phone.trimmingCharacters(in: .whitespaces)
        if name.isEmpty || phone.isEmpty { alert = ErrorAlert(message: "Nombre y teléfono son obligatorios."); return }
        patient.name = name
        patient.phone = phone
        patient.age = Int(ageText) ?? 0
        if isNew { store.patients.append(patient) }
        else if let i = store.patients.firstIndex(where: { $0.id == patient.id }) { store.patients[i] = patient }
        dismiss()
    }
}
