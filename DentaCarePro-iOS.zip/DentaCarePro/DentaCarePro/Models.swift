import Foundation

struct Patient: Identifiable, Codable, Hashable {
    var id: String
    var name: String
    var age: Int
    var phone: String
    var email: String
    var address: String
    var sex: String          // "M", "F", "O"
    var bloodType: String
    var allergies: String
    var diseases: String
    var createdAt: String    // yyyy-MM-dd
}

struct Treatment: Identifiable, Codable, Hashable {
    var id: String
    var name: String
    var price: Double
    var duration: Int
    var description: String
    var category: String
}

struct Appointment: Identifiable, Codable, Hashable {
    var id: String
    var patientId: String
    var treatmentId: String
    var date: String         // yyyy-MM-dd
    var time: String         // HH:mm
    var status: String
    var notes: String
    var dentist: String
}

struct ClinicalRecord: Identifiable, Codable, Hashable {
    var id: String
    var patientId: String
    var date: String
    var treatment: String
    var diagnosis: String
    var observations: String
    var prescription: String
    var dentist: String
}

struct Payment: Identifiable, Codable, Hashable {
    var id: String
    var patientId: String
    var appointmentId: String
    var amount: Double
    var method: String
    var date: String
    var treatmentName: String
    var status: String
}

struct DentalImage: Identifiable, Codable, Hashable {
    var id: String
    var patientId: String
    var type: String
    var description: String
    var fileName: String?    // archivo dentro de Documents/images
    var date: String
}

struct AppUser: Identifiable, Codable, Hashable {
    var id: String
    var email: String
    var password: String
    var role: String         // "admin" | "patient"
    var name: String
    var patientId: String?
    var isAdmin: Bool { role == "admin" }
}

enum Catalog {
    static let statuses = ["Pendiente", "Confirmada", "En proceso", "Finalizada", "Cancelada"]
    static let bloodTypes = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]
    static let sexes: [(String, String)] = [("M", "Masculino"), ("F", "Femenino"), ("O", "Otro")]
    static let paymentMethods = ["Efectivo", "Tarjeta", "Transferencia", "Cheque"]
    static let imageTypes = ["Radiografía", "Foto intraoral", "Foto extraoral", "Panorámica", "Cefalometría"]
    static let categories = ["Preventivo", "Cirugía", "Restaurativo", "Prostodoncia", "Estético", "Ortodoncia", "Implantología"]
}

// MARK: - Datos semilla (los mismos de la versión web)
enum Seed {
    static var today: String { Fmt.todayString }

    static let treatments: [Treatment] = [
        Treatment(id: "t1", name: "Consulta General", price: 500, duration: 30, description: "Revisión y diagnóstico general", category: "Preventivo"),
        Treatment(id: "t2", name: "Limpieza Dental", price: 800, duration: 45, description: "Profilaxis dental completa", category: "Preventivo"),
        Treatment(id: "t3", name: "Extracción Simple", price: 1200, duration: 45, description: "Extracción de pieza dental simple", category: "Cirugía"),
        Treatment(id: "t4", name: "Extracción Molar", price: 2500, duration: 90, description: "Extracción de molar o cordal", category: "Cirugía"),
        Treatment(id: "t5", name: "Resina/Empaste", price: 900, duration: 60, description: "Restauración con resina compuesta", category: "Restaurativo"),
        Treatment(id: "t6", name: "Endodoncia", price: 4500, duration: 120, description: "Tratamiento de conducto radicular", category: "Restaurativo"),
        Treatment(id: "t7", name: "Corona Porcelana", price: 7000, duration: 90, description: "Corona de porcelana o zirconio", category: "Prostodoncia"),
        Treatment(id: "t8", name: "Blanqueamiento", price: 3500, duration: 90, description: "Blanqueamiento dental profesional", category: "Estético"),
        Treatment(id: "t9", name: "Ortodoncia Inicial", price: 15000, duration: 60, description: "Colocación de aparato fijo", category: "Ortodoncia"),
        Treatment(id: "t10", name: "Implante Dental", price: 18000, duration: 120, description: "Implante dental titanio + corona", category: "Implantología"),
    ]

    static let patients: [Patient] = [
        Patient(id: "p1", name: "María García López", age: 34, phone: "981-234-5678", email: "maria.garcia@email.com", address: "Av. Reforma 123, Campeche", sex: "F", bloodType: "O+", allergies: "Penicilina", diseases: "Hipertensión", createdAt: "2024-01-15"),
        Patient(id: "p2", name: "Carlos Hernández Ruiz", age: 45, phone: "981-876-5432", email: "carlos.h@email.com", address: "Calle 59 #234, Campeche", sex: "M", bloodType: "A+", allergies: "Ninguna", diseases: "Diabetes Tipo 2", createdAt: "2024-02-20"),
        Patient(id: "p3", name: "Ana Martínez Soto", age: 28, phone: "981-456-7890", email: "ana.martinez@email.com", address: "Col. Roma 45, Campeche", sex: "F", bloodType: "B-", allergies: "Ibuprofeno", diseases: "Ninguna", createdAt: "2024-03-10"),
        Patient(id: "p4", name: "Luis Rodríguez Torres", age: 52, phone: "981-321-6547", email: "luis.rt@email.com", address: "Fraccionamiento Las Flores, Campeche", sex: "M", bloodType: "AB+", allergies: "Látex", diseases: "Ninguna", createdAt: "2024-04-05"),
    ]

    static var appointments: [Appointment] {
        let t = today
        return [
            Appointment(id: "a1", patientId: "p1", treatmentId: "t2", date: t, time: "09:00", status: "Confirmada", notes: "Limpieza semestral", dentist: "Dr. González"),
            Appointment(id: "a2", patientId: "p2", treatmentId: "t1", date: t, time: "10:30", status: "En proceso", notes: "Revisión de rutina", dentist: "Dr. González"),
            Appointment(id: "a3", patientId: "p3", treatmentId: "t5", date: t, time: "12:00", status: "Pendiente", notes: "Restauración molar", dentist: "Dra. López"),
            Appointment(id: "a4", patientId: "p4", treatmentId: "t8", date: t, time: "15:00", status: "Pendiente", notes: "Blanqueamiento inicial", dentist: "Dra. López"),
            Appointment(id: "a5", patientId: "p1", treatmentId: "t6", date: "2025-05-20", time: "11:00", status: "Pendiente", notes: "Endodoncia molar #26", dentist: "Dr. González"),
            Appointment(id: "a6", patientId: "p2", treatmentId: "t7", date: "2025-05-22", time: "14:00", status: "Confirmada", notes: "Segunda corona", dentist: "Dr. González"),
        ]
    }

    static let records: [ClinicalRecord] = [
        ClinicalRecord(id: "cr1", patientId: "p1", date: "2024-06-15", treatment: "Limpieza Dental", diagnosis: "Gingivitis leve",
                       observations: "Paciente con acumulación de sarro en cuadrante inferior. Se realizó profilaxis completa.",
                       prescription: "Colutorio con Clorhexidina 0.12% cada 12 hrs por 7 días.", dentist: "Dr. González"),
        ClinicalRecord(id: "cr2", patientId: "p2", date: "2024-08-20", treatment: "Extracción Simple", diagnosis: "Caries profunda en pieza 46",
                       observations: "Pieza con destrucción coronal mayor al 80%. Se realiza extracción bajo anestesia local.",
                       prescription: "Amoxicilina 500mg cada 8 hrs por 5 días. Ibuprofeno 400mg cada 6 hrs.", dentist: "Dr. González"),
        ClinicalRecord(id: "cr3", patientId: "p3", date: "2025-01-10", treatment: "Resina/Empaste", diagnosis: "Caries interproximal piezas 14 y 15",
                       observations: "Restauración con resina en clases I y II. Ajuste de oclusión realizado.",
                       prescription: "Ninguna.", dentist: "Dra. López"),
    ]

    static var payments: [Payment] {
        let t = today
        return [
            Payment(id: "pay1", patientId: "p1", appointmentId: "a1", amount: 800, method: "Efectivo", date: t, treatmentName: "Limpieza Dental", status: "Pagado"),
            Payment(id: "pay2", patientId: "p2", appointmentId: "a2", amount: 500, method: "Tarjeta", date: t, treatmentName: "Consulta General", status: "Pagado"),
            Payment(id: "pay3", patientId: "p1", appointmentId: "cr1", amount: 800, method: "Efectivo", date: "2024-06-15", treatmentName: "Limpieza Dental", status: "Pagado"),
            Payment(id: "pay4", patientId: "p2", appointmentId: "cr2", amount: 1200, method: "Transferencia", date: "2024-08-20", treatmentName: "Extracción Simple", status: "Pagado"),
        ]
    }

    static let users: [AppUser] = [
        AppUser(id: "admin1", email: "dentista@clinica.mx", password: "1234", role: "admin", name: "Dr. González", patientId: nil),
        AppUser(id: "p1", email: "maria.garcia@email.com", password: "1234", role: "patient", name: "María García López", patientId: "p1"),
        AppUser(id: "p2", email: "carlos.h@email.com", password: "1234", role: "patient", name: "Carlos Hernández Ruiz", patientId: "p2"),
    ]
}
