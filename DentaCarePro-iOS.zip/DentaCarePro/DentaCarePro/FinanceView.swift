import SwiftUI

struct FinanceView: View {
    @EnvironmentObject var store: DataStore
    @State private var period = "today"
    @State private var showAdd = false
    @State private var receipt: Payment?

    private let periods: [(String, String)] = [("today", "Hoy"), ("week", "Esta Semana"), ("month", "Este Mes"), ("all", "Todo")]

    private var filtered: [Payment] {
        let today = Fmt.todayString
        let weekAgo = Fmt.isoFormatter.string(from: Date().addingTimeInterval(-7 * 86400))
        let cal = Calendar.current
        let start = cal.date(from: cal.dateComponents([.year, .month], from: Date())) ?? Date()
        let monthStart = Fmt.isoFormatter.string(from: start)
        return store.payments.filter { p in
            switch period {
            case "today": return p.date == today
            case "week": return p.date >= weekAgo
            case "month": return p.date >= monthStart
            default: return true
            }
        }
    }

    var body: some View {
        let list = filtered
        let total = list.reduce(0) { $0 + $1.amount }
        let efectivo = list.filter { $0.method == "Efectivo" }.reduce(0) { $0 + $1.amount }
        let electronico = list.filter { $0.method == "Tarjeta" || $0.method == "Transferencia" }.reduce(0) { $0 + $1.amount }

        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    ChipRow(options: periods, selection: $period)
                    StatGrid {
                        StatCard(label: "Total del Período", value: Fmt.money(total), icon: "💰", color: AppColor.success)
                        StatCard(label: "Num. de Cobros", value: "\(list.count)", icon: "🧾", color: AppColor.primary)
                        StatCard(label: "Efectivo", value: Fmt.money(efectivo), icon: "💵", color: AppColor.warning)
                        StatCard(label: "Tarjeta / Transfer.", value: Fmt.money(electronico), icon: "💳", color: AppColor.secondary)
                    }
                    if list.isEmpty { EmptyCard(icon: "🧾", text: "Sin pagos en este período") }
                    ForEach(Array(list.reversed())) { pay in
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text(store.patient(pay.patientId)?.name ?? "—").font(.headline)
                                Spacer()
                                Text(Fmt.money(pay.amount)).font(.headline).foregroundStyle(AppColor.success)
                            }
                            Text(pay.treatmentName).foregroundStyle(AppColor.textMuted)
                            HStack {
                                Badge(label: pay.method, color: Color(hex: "065F46"), bg: Color(hex: "F0FDF4"))
                                Badge(label: pay.status)
                                Text(Fmt.date(pay.date)).font(.footnote).foregroundStyle(AppColor.textMuted)
                                Spacer()
                                Button("🧾 Recibo") { receipt = pay }.buttonStyle(.bordered).font(.footnote)
                            }
                        }
                        .padding(14).frame(maxWidth: .infinity, alignment: .leading).cardBackground()
                    }
                }
                .padding(16)
            }
            .screenBackground()
            .navigationTitle("Finanzas")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { showAdd = true } label: { Label("Registrar pago", systemImage: "plus") }
                }
                ToolbarItem(placement: .topBarTrailing) { UserMenu() }
            }
            .sheet(isPresented: $showAdd) { PaymentFormSheet() }
            .sheet(item: $receipt) { p in ReceiptSheet(payment: p) }
        }
    }
}

struct PaymentFormSheet: View {
    @EnvironmentObject var store: DataStore
    @Environment(\.dismiss) private var dismiss
    @State private var patientId = ""
    @State private var concept = ""
    @State private var amount = ""
    @State private var method = "Efectivo"
    @State private var alert: ErrorAlert?

    var body: some View {
        NavigationStack {
            Form {
                Picker("Paciente *", selection: $patientId) {
                    Text("Seleccionar paciente...").tag("")
                    ForEach(store.patients) { Text($0.name).tag($0.id) }
                }
                TextField("Concepto / Tratamiento * (Ej: Limpieza Dental)", text: $concept)
                TextField("Monto (MX$) *", text: $amount).keyboardType(.decimalPad)
                Picker("Método de pago", selection: $method) {
                    ForEach(Catalog.paymentMethods, id: \.self) { Text($0).tag($0) }
                }
            }
            .navigationTitle("Registrar Pago")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Registrar") { save() } }
            }
            .alert(item: $alert) { Alert(title: Text("Atención"), message: Text($0.message)) }
        }
    }

    private func save() {
        let value = Double(amount.replacingOccurrences(of: ",", with: ".")) ?? 0
        if patientId.isEmpty || value <= 0 || concept.trimmingCharacters(in: .whitespaces).isEmpty {
            alert = ErrorAlert(message: "Completa los campos obligatorios."); return
        }
        store.payments.append(Payment(id: DataStore.newId(), patientId: patientId, appointmentId: "", amount: value,
                                      method: method, date: Fmt.todayString, treatmentName: concept, status: "Pagado"))
        dismiss()
    }
}

struct ReceiptSheet: View {
    @EnvironmentObject var store: DataStore
    @Environment(\.dismiss) private var dismiss
    let payment: Payment

    private var rows: [(String, String)] {
        [("Folio", payment.id.uppercased()),
         ("Paciente", store.patient(payment.patientId)?.name ?? "—"),
         ("Concepto", payment.treatmentName),
         ("Método", payment.method),
         ("Fecha", Fmt.date(payment.date))]
    }

    private var plainText: String {
        "DentaCare Pro — Recibo Oficial de Pago\n"
        + rows.map { "\($0.0): \($0.1)" }.joined(separator: "\n")
        + "\nTOTAL: \(Fmt.money(payment.amount))\n¡Gracias por su preferencia!"
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 14) {
                    Text("🦷").font(.system(size: 36))
                    Text("DentaCare Pro").font(.title3.weight(.bold)).foregroundStyle(AppColor.primary)
                    Text("Recibo Oficial de Pago").font(.caption).foregroundStyle(AppColor.textMuted)
                    ForEach(rows, id: \.0) { l, v in
                        HStack {
                            Text(l).foregroundStyle(AppColor.textMuted)
                            Spacer()
                            Text(v).fontWeight(.semibold).multilineTextAlignment(.trailing)
                        }
                        .font(.subheadline)
                        Divider()
                    }
                    HStack {
                        Text("TOTAL").fontWeight(.bold)
                        Spacer()
                        Text(Fmt.money(payment.amount)).font(.title3.weight(.heavy))
                    }
                    .foregroundStyle(AppColor.primaryDark)
                    .padding(12).background(AppColor.primaryLight).clipShape(RoundedRectangle(cornerRadius: 8))
                    Text("¡Gracias por su preferencia!").font(.caption2).foregroundStyle(AppColor.textLight)
                }
                .padding(20)
                .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(AppColor.border, style: StrokeStyle(lineWidth: 2, dash: [6])))
                .padding(16)
            }
            .navigationTitle("Recibo de Pago")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cerrar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { ShareLink(item: plainText) }
            }
        }
    }
}
