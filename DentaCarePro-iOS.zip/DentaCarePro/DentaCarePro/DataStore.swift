import SwiftUI
import UIKit

enum AdminTab: Hashable {
    case dashboard, patients, appointments, clinical, imaging, finance, treatments
}

/// Almacén de datos de la app. Reemplaza al localStorage de la versión web:
/// todo se guarda como JSON en la carpeta Documents del dispositivo.
final class DataStore: ObservableObject {
    @Published var patients: [Patient] { didSet { save() } }
    @Published var appointments: [Appointment] { didSet { save() } }
    @Published var records: [ClinicalRecord] { didSet { save() } }
    @Published var payments: [Payment] { didSet { save() } }
    @Published var treatments: [Treatment] { didSet { save() } }
    @Published var images: [DentalImage] { didSet { save() } }
    @Published var users: [AppUser] { didSet { save() } }

    // Estado de sesión y navegación (no se guarda)
    @Published var currentUser: AppUser?
    @Published var adminTab: AdminTab = .dashboard
    @Published var clinicalPatientId: String?

    private struct Snapshot: Codable {
        var patients: [Patient]
        var appointments: [Appointment]
        var records: [ClinicalRecord]
        var payments: [Payment]
        var treatments: [Treatment]
        var images: [DentalImage]
        var users: [AppUser]
    }

    private static var documents: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    private static var dataURL: URL { documents.appendingPathComponent("dentacare.json") }
    private static var imagesDir: URL {
        let url = documents.appendingPathComponent("images", isDirectory: true)
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }

    private let imageCache = NSCache<NSString, UIImage>()

    init() {
        if let data = try? Data(contentsOf: Self.dataURL),
           let s = try? JSONDecoder().decode(Snapshot.self, from: data) {
            patients = s.patients
            appointments = s.appointments
            records = s.records
            payments = s.payments
            treatments = s.treatments
            images = s.images
            users = s.users
        } else {
            patients = Seed.patients
            appointments = Seed.appointments
            records = Seed.records
            payments = Seed.payments
            treatments = Seed.treatments
            images = []
            users = Seed.users
            save()
        }
    }

    private func save() {
        let s = Snapshot(patients: patients, appointments: appointments, records: records,
                         payments: payments, treatments: treatments, images: images, users: users)
        do {
            let data = try JSONEncoder().encode(s)
            try data.write(to: Self.dataURL, options: .atomic)
        } catch {
            print("No se pudo guardar:", error)
        }
    }

    /// Borra todo y vuelve a los datos de ejemplo.
    func resetToSeed() {
        for img in images { if let f = img.fileName { try? FileManager.default.removeItem(at: Self.imagesDir.appendingPathComponent(f)) } }
        imageCache.removeAllObjects()
        patients = Seed.patients
        appointments = Seed.appointments
        records = Seed.records
        payments = Seed.payments
        treatments = Seed.treatments
        images = []
        users = Seed.users
    }

    // MARK: - Utilidades
    static func newId() -> String { "id" + UUID().uuidString.prefix(8).lowercased() }
    func patient(_ id: String) -> Patient? { patients.first { $0.id == id } }
    func treatment(_ id: String) -> Treatment? { treatments.first { $0.id == id } }

    // MARK: - Sesión
    func login(email: String, password: String) -> Bool {
        let e = email.trimmingCharacters(in: .whitespaces)
        guard let u = users.first(where: { $0.email == e && $0.password == password }) else { return false }
        adminTab = .dashboard
        clinicalPatientId = nil
        currentUser = u
        return true
    }

    /// Devuelve un mensaje de error, o nil si se registró bien.
    func register(name: String, email: String, password: String, confirm: String) -> String? {
        let n = name.trimmingCharacters(in: .whitespaces)
        let e = email.trimmingCharacters(in: .whitespaces)
        if n.isEmpty || e.isEmpty || password.isEmpty { return "Completa todos los campos." }
        if password != confirm { return "Las contraseñas no coinciden." }
        if users.contains(where: { $0.email == e }) { return "Este correo ya está registrado." }
        let user = AppUser(id: Self.newId(), email: e, password: password, role: "patient", name: n, patientId: nil)
        users.append(user)
        currentUser = user
        return nil
    }

    func logout() {
        currentUser = nil
        adminTab = .dashboard
        clinicalPatientId = nil
    }

    func openClinical(for patientId: String) {
        clinicalPatientId = patientId
        adminTab = .clinical
    }

    // MARK: - Citas y pagos
    func finalizeAndPay(_ apt: Appointment) {
        guard let t = treatment(apt.treatmentId) else { return }
        let pay = Payment(id: Self.newId(), patientId: apt.patientId, appointmentId: apt.id, amount: t.price,
                          method: "Efectivo", date: Fmt.todayString, treatmentName: t.name, status: "Pagado")
        payments.append(pay)
        if let i = appointments.firstIndex(where: { $0.id == apt.id }) {
            appointments[i].status = "Finalizada"
        }
    }

    // MARK: - Imágenes
    func addImage(data: Data, patientId: String, type: String, description: String) {
        var fileName: String? = nil
        if let ui = UIImage(data: data) {
            let maxSide: CGFloat = 1600
            let scale = min(1, maxSide / max(ui.size.width, ui.size.height))
            let newSize = CGSize(width: ui.size.width * scale, height: ui.size.height * scale)
            let rendered = UIGraphicsImageRenderer(size: newSize).image { _ in
                ui.draw(in: CGRect(origin: .zero, size: newSize))
            }
            if let jpg = rendered.jpegData(compressionQuality: 0.8) {
                let name = Self.newId() + ".jpg"
                do {
                    try jpg.write(to: Self.imagesDir.appendingPathComponent(name), options: .atomic)
                    fileName = name
                } catch { print("No se pudo guardar la imagen:", error) }
            }
        }
        images.append(DentalImage(id: Self.newId(), patientId: patientId, type: type, description: description,
                                  fileName: fileName, date: Fmt.todayString))
    }

    func addImageWithoutFile(patientId: String, type: String, description: String) {
        images.append(DentalImage(id: Self.newId(), patientId: patientId, type: type, description: description,
                                  fileName: nil, date: Fmt.todayString))
    }

    func uiImage(for img: DentalImage) -> UIImage? {
        guard let f = img.fileName else { return nil }
        if let c = imageCache.object(forKey: f as NSString) { return c }
        guard let ui = UIImage(contentsOfFile: Self.imagesDir.appendingPathComponent(f).path) else { return nil }
        imageCache.setObject(ui, forKey: f as NSString)
        return ui
    }

    func deleteImage(_ img: DentalImage) {
        if let f = img.fileName {
            try? FileManager.default.removeItem(at: Self.imagesDir.appendingPathComponent(f))
            imageCache.removeObject(forKey: f as NSString)
        }
        images.removeAll { $0.id == img.id }
    }
}
