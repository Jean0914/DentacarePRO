import SwiftUI

extension Color {
    init(hex: String) {
        let s = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        var v: UInt64 = 0
        _ = Scanner(string: s).scanHexInt64(&v)
        self.init(.sRGB,
                  red: Double((v >> 16) & 0xFF) / 255,
                  green: Double((v >> 8) & 0xFF) / 255,
                  blue: Double(v & 0xFF) / 255,
                  opacity: 1)
    }
}

enum AppColor {
    static let primary = Color(hex: "0EA5E9")
    static let primaryDark = Color(hex: "0284C7")
    static let primaryLight = Color(hex: "E0F2FE")
    static let secondary = Color(hex: "6366F1")
    static let success = Color(hex: "10B981")
    static let warning = Color(hex: "F59E0B")
    static let danger = Color(hex: "EF4444")
    static let bg = Color(hex: "F0F9FF")
    static let surfaceAlt = Color(hex: "F8FAFC")
    static let border = Color(hex: "E2E8F0")
    static let text = Color(hex: "0F172A")
    static let textMuted = Color(hex: "64748B")
    static let textLight = Color(hex: "94A3B8")
    static let sidebar = Color(hex: "0C4A6E")

    static func status(_ s: String) -> Color {
        switch s {
        case "Pendiente": return warning
        case "Confirmada": return primary
        case "En proceso": return secondary
        case "Finalizada": return success
        case "Cancelada": return danger
        default: return textMuted
        }
    }
    static func statusBg(_ s: String) -> Color {
        switch s {
        case "Pendiente": return Color(hex: "FFF7ED")
        case "Confirmada": return primaryLight
        case "En proceso": return Color(hex: "EEF2FF")
        case "Finalizada": return Color(hex: "D1FAE5")
        case "Cancelada": return Color(hex: "FEE2E2")
        default: return Color(hex: "F1F5F9")
        }
    }
}

// MARK: - Formato
enum Fmt {
    static let isoFormatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyy-MM-dd"
        return f
    }()
    static let timeFormatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "HH:mm"
        return f
    }()

    static var todayString: String { isoFormatter.string(from: Date()) }

    static func money(_ n: Double) -> String {
        let f = NumberFormatter()
        f.numberStyle = .decimal
        f.locale = Locale(identifier: "es_MX")
        f.maximumFractionDigits = 2
        return "MX$" + (f.string(from: NSNumber(value: n)) ?? "\(n)")
    }

    /// "2025-05-20" -> "20/05/2025"
    static func date(_ d: String) -> String {
        let p = d.split(separator: "-")
        guard p.count == 3 else { return d.isEmpty ? "—" : d }
        return "\(p[2])/\(p[1])/\(p[0])"
    }

    static func toDate(_ s: String) -> Date { isoFormatter.date(from: s) ?? Date() }
    static func toTime(_ s: String) -> Date { timeFormatter.date(from: s) ?? timeFormatter.date(from: "09:00")! }
}

// MARK: - Componentes reutilizables
struct Badge: View {
    let label: String
    var color: Color? = nil
    var bg: Color? = nil
    var body: some View {
        Text(label)
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 10).padding(.vertical, 3)
            .background(bg ?? AppColor.statusBg(label))
            .foregroundStyle(color ?? AppColor.status(label))
            .clipShape(Capsule())
            .lineLimit(1)
    }
}

struct StatCard: View {
    let label: String
    let value: String
    let icon: String
    let color: Color
    var sub: String? = nil
    var body: some View {
        HStack(spacing: 12) {
            Text(icon).font(.title2)
                .frame(width: 46, height: 46)
                .background(color.opacity(0.15))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            VStack(alignment: .leading, spacing: 2) {
                Text(label).font(.caption).foregroundStyle(AppColor.textMuted)
                Text(value).font(.title3.weight(.heavy)).foregroundStyle(AppColor.text)
                    .minimumScaleFactor(0.6).lineLimit(1)
                if let sub { Text(sub).font(.caption2).foregroundStyle(AppColor.textLight) }
            }
            Spacer(minLength: 0)
        }
        .padding(14)
        .cardBackground()
    }
}

struct CardBackground: ViewModifier {
    func body(content: Content) -> some View {
        content
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(AppColor.border, lineWidth: 1))
    }
}
extension View {
    func cardBackground() -> some View { modifier(CardBackground()) }
    func screenBackground() -> some View { self.background(AppColor.bg.ignoresSafeArea()) }
}

struct StatGrid<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
            content
        }
    }
}

struct ChipRow: View {
    let options: [(String, String)]   // (valor, etiqueta)
    @Binding var selection: String
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(options, id: \.0) { value, label in
                    Button { selection = value } label: {
                        Text(label)
                            .font(.subheadline.weight(.semibold))
                            .padding(.horizontal, 14).padding(.vertical, 8)
                            .background(selection == value ? AppColor.primaryLight : Color.white)
                            .foregroundStyle(selection == value ? AppColor.primaryDark : AppColor.textMuted)
                            .clipShape(Capsule())
                            .overlay(Capsule().stroke(selection == value ? AppColor.primary : AppColor.border))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 2)
        }
    }
}

struct EmptyCard: View {
    let icon: String
    let text: String
    var body: some View {
        VStack(spacing: 8) {
            Text(icon).font(.system(size: 44))
            Text(text).foregroundStyle(AppColor.textMuted).multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(32)
        .cardBackground()
    }
}

struct ErrorAlert: Identifiable { let id = UUID(); let message: String }
