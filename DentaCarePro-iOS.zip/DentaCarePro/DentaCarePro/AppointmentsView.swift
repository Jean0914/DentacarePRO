import SwiftUI

struct AppointmentsView: View {
    @EnvironmentObject var store: DataStore
    @State private var filterByDate = true
    @State private var filterDate = Date()
    @State private var filterStatus = "Todas"
    @State private var editing: Appointment?

    private var statusOptions: [(String, String)] {
        (["Todas"] + Catalog.statuses).map { ($0, $0) }
    }

    private var filtered: [Appointment] {
        let day = Fmt.isoFormatter.string(from: filterDate)
        return store.appointments
            .filter { (!filterByDate || $0.date == day) && (filterStatus == "Todas" || $0.status == filterStatus) }
            .sorted { ($0.date, $0.time) < ($1.date, $1.time) }
    }

    private func newAppointment() -> Appointment {
        Appointment(id: DataStore.newId(), patientId: "", treatmentId: "",
                    date: Fmt.todayString, time: "09:00", status: "Pendiente", notes: "", dentist: "Dr. González")
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Toggle("Filtrar por fecha", isOn: $filterByDate).labelsHidden()
                        if filterByDate {
                            DatePicker("Fecha", selection: $filterDate, displayedComponents: .date).labelsHidden()
                        } else {
                            Text("Todas las fechas").foregroundStyle(AppColor.textMuted)
                        }
                        Spacer()
                    }
                    ChipRow(options: statusOptions, selection: $filterStatus)

                    if filtered.isEmpty {
                        EmptyCard(icon: "📅", text: "Sin citas en este período")
                    }
                    ForEach(filtered) { a in
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text(store.patient(a.patientId)?.name ?? "—").font(.headline)
                                Spacer()
                                Badge(label: a.status)
                            }
                            Text(store.treatment(a.treatmentId)?.name ?? "—").foregroundStyle(AppColor.textMuted)
                            HStack {
                                Text(Fmt.date(a.date)).font(.subheadline)
                                Badge(label: a.time, color: AppColor.primaryDark, bg: AppColor.primaryLight)
                                Text(a.dentist).font(.footnote).foregroundStyle(AppColor.textMuted)
                            }
                            if !a.notes.isEmpty { Text(a.notes).font(.caption).foregroundStyle(AppColor.textLight) }
                            HStack {
                                Button("✏️ Editar") { editing = a }.buttonStyle(.bordered)
                                if a.status == "En proceso" || a.status == "Confirmada" {
                                    Button("✅ Finalizar") { store.finalizeAndPay(a) }
                                        .buttonStyle(.borderedProminent).tint(AppColor.success)
                                }
                            }
                            .font(.footnote)
                        }
                        .padding(14).frame(maxWidth: .infinity, alignment: .leading).cardBackground()
                    }
                }
                .padding(16)
            }
            .screenBackground()
            .navigationTitle("Citas")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { editing = newAppointment() } label: { Label("Nueva cita", systemImage: "plus") }
                }
                ToolbarItem(placement: .topBarTrailing) { UserMenu() }
            }
            .sheet(item: $editing) { a in
                AppointmentFormSheet(appointment: a, isNew: !store.appointments.contains(where: { $0.id == a.id }))
            }
        }
    }
}

struct AppointmentFormSheet: View {
    @EnvironmentObject var store: DataStore
    @Environment(\.dismiss) private var dismiss
    @State var appointment: Appointment
    let isNew: Bool
    @State private var date = Date()
    @State private var time = Date()
    @State private var alert: ErrorAlert?

    var body: some View {
        NavigationStack {
            Form {
                Picker("Paciente *", selection: $appointment.patientId) {
                    Text("Seleccionar paciente...").tag("")
                    ForEach(store.patients) { Text($0.name).tag($0.id) }
                }
                Picker("Tratamiento *", selection: $appointment.treatmentId) {
                    Text("Seleccionar tratamiento...").tag("")
                    ForEach(store.treatments) { Text("\($0.name) — \(Fmt.money($0.price))").tag($0.id) }
                }
                DatePicker("Fecha *", selection: $date, displayedComponents: .date)
                DatePicker("Hora", selection: $time, displayedComponents: .hourAndMinute)
                TextField("Dentista", text: $appointment.dentist)
                Picker("Estado", selection: $appointment.status) {
                    ForEach(Catalog.statuses, id: \.self) { Text($0).tag($0) }
                }
                Section("Notas") {
                    TextField("Notas", text: $appointment.notes, axis: .vertical).lineLimit(3...6)
                }
            }
            .navigationTitle(isNew ? "Nueva Cita" : "Editar Cita")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Guardar") { save() } }
            }
            .onAppear {
                date = Fmt.toDate(appointment.date)
                time = Fmt.toTime(appointment.time)
            }
            .alert(item: $alert) { Alert(title: Text("Atención"), message: Text($0.message)) }
        }
    }

    private func save() {
        if appointment.patientId.isEmpty || appointment.treatmentId.isEmpty {
            alert = ErrorAlert(message: "Completa los campos obligatorios."); return
        }
        appointment.date = Fmt.isoFormatter.string(from: date)
        appointment.time = Fmt.timeFormatter.string(from: time)
        if isNew { store.appointments.append(appointment) }
        else if let i = store.appointments.firstIndex(where: { $0.id == appointment.id }) { store.appointments[i] = appointment }
        dismiss()
    }
}
