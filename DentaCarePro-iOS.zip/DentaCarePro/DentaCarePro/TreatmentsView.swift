import SwiftUI

struct TreatmentsView: View {
    @EnvironmentObject var store: DataStore
    @State private var editing: Treatment?
    @State private var toDelete: Treatment?

    private static let catColors: [String: (Color, Color)] = [
        "Preventivo": (Color(hex: "ECFDF5"), Color(hex: "065F46")),
        "Cirugía": (Color(hex: "FEF2F2"), Color(hex: "991B1B")),
        "Restaurativo": (Color(hex: "EFF6FF"), Color(hex: "1E40AF")),
        "Prostodoncia": (Color(hex: "F5F3FF"), Color(hex: "5B21B6")),
        "Estético": (Color(hex: "FFF7ED"), Color(hex: "9A3412")),
        "Ortodoncia": (Color(hex: "F0FDF4"), Color(hex: "166534")),
        "Implantología": (Color(hex: "ECFEFF"), Color(hex: "155E75")),
    ]

    private var categories: [String] {
        var seen: [String] = []
        for t in store.treatments where !seen.contains(t.category) { seen.append(t.category) }
        return seen
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    ForEach(categories, id: \.self) { cat in
                        let items = store.treatments.filter { $0.category == cat }
                        let colors = Self.catColors[cat] ?? (Color(hex: "F1F5F9"), Color(hex: "334155"))
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Badge(label: cat, color: colors.1, bg: colors.0)
                                Text("\(items.count) tratamientos").font(.footnote).foregroundStyle(AppColor.textLight)
                            }
                            ForEach(items) { t in
                                VStack(alignment: .leading, spacing: 8) {
                                    HStack(alignment: .top) {
                                        Text(t.name).font(.headline)
                                        Spacer()
                                        Text(Fmt.money(t.price)).font(.headline).foregroundStyle(AppColor.success)
                                    }
                                    Text(t.description).font(.subheadline).foregroundStyle(AppColor.textMuted)
                                    HStack {
                                        Text("⏱ \(t.duration) min").font(.caption).foregroundStyle(AppColor.textLight)
                                        Spacer()
                                        Button("✏️") { editing = t }.buttonStyle(.bordered)
                                        Button("🗑️") { toDelete = t }.buttonStyle(.bordered).tint(AppColor.danger)
                                    }
                                }
                                .padding(14).frame(maxWidth: .infinity, alignment: .leading).cardBackground()
                            }
                        }
                    }
                }
                .padding(16)
            }
            .screenBackground()
            .navigationTitle("Tratamientos")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        editing = Treatment(id: DataStore.newId(), name: "", price: 0, duration: 30, description: "", category: "Preventivo")
                    } label: { Label("Nuevo tratamiento", systemImage: "plus") }
                }
                ToolbarItem(placement: .topBarTrailing) { UserMenu() }
            }
            .sheet(item: $editing) { t in
                TreatmentFormSheet(treatment: t, isNew: !store.treatments.contains(where: { $0.id == t.id }))
            }
            .alert("¿Eliminar tratamiento?", isPresented: Binding(get: { toDelete != nil }, set: { if !$0 { toDelete = nil } })) {
                Button("Cancelar", role: .cancel) { toDelete = nil }
                Button("Eliminar", role: .destructive) {
                    if let t = toDelete { store.treatments.removeAll { $0.id == t.id } }
                    toDelete = nil
                }
            } message: { Text(toDelete?.name ?? "") }
        }
    }
}

struct TreatmentFormSheet: View {
    @EnvironmentObject var store: DataStore
    @Environment(\.dismiss) private var dismiss
    @State var treatment: Treatment
    let isNew: Bool
    @State private var priceText = ""
    @State private var durationText = ""
    @State private var alert: ErrorAlert?

    var body: some View {
        NavigationStack {
            Form {
                TextField("Nombre *", text: $treatment.name)
                TextField("Precio (MX$) *", text: $priceText).keyboardType(.decimalPad)
                TextField("Duración (min)", text: $durationText).keyboardType(.numberPad)
                Picker("Categoría", selection: $treatment.category) {
                    ForEach(Catalog.categories, id: \.self) { Text($0).tag($0) }
                }
                Section("Descripción") { TextField("Descripción", text: $treatment.description, axis: .vertical).lineLimit(2...5) }
            }
            .navigationTitle(isNew ? "Nuevo Tratamiento" : "Editar Tratamiento")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Guardar") { save() } }
            }
            .onAppear {
                priceText = treatment.price > 0 ? String(format: "%g", treatment.price) : ""
                durationText = treatment.duration > 0 ? String(treatment.duration) : ""
            }
            .alert(item: $alert) { Alert(title: Text("Atención"), message: Text($0.message)) }
        }
    }

    private func save() {
        let price = Double(priceText.replacingOccurrences(of: ",", with: ".")) ?? 0
        if treatment.name.trimmingCharacters(in: .whitespaces).isEmpty || price <= 0 {
            alert = ErrorAlert(message: "Nombre y precio son obligatorios."); return
        }
        treatment.price = price
        treatment.duration = Int(durationText) ?? 0
        if isNew { store.treatments.append(treatment) }
        else if let i = store.treatments.firstIndex(where: { $0.id == treatment.id }) { store.treatments[i] = treatment }
        dismiss()
    }
}
