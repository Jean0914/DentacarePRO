import SwiftUI
import Charts

struct DashboardView: View {
    @EnvironmentObject var store: DataStore

    private struct MonthRevenue: Identifiable { let id: String; let amount: Double }

    var body: some View {
        let today = Fmt.todayString
        let todayApts = store.appointments.filter { $0.date == today }.sorted { $0.time < $1.time }
        let todayRevenue = store.payments.filter { $0.date == today }.reduce(0) { $0 + $1.amount }
        let waiting = todayApts.filter { $0.status == "Pendiente" || $0.status == "Confirmada" }.count
        let inProcess = todayApts.filter { $0.status == "En proceso" }.count
        // Igual que la versión web: datos de ejemplo para los meses anteriores.
        let revenue: [MonthRevenue] = [
            .init(id: "Ene", amount: 18500), .init(id: "Feb", amount: 22000), .init(id: "Mar", amount: 19800),
            .init(id: "Abr", amount: 25000), .init(id: "May", amount: 23400), .init(id: "Jun", amount: todayRevenue + 14200),
        ]

        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    StatGrid {
                        StatCard(label: "Citas de Hoy", value: "\(todayApts.count)", icon: "📅", color: AppColor.primary, sub: "\(inProcess) en proceso")
                        StatCard(label: "En Espera", value: "\(waiting)", icon: "⏳", color: AppColor.warning, sub: "pacientes hoy")
                        StatCard(label: "Total Pacientes", value: "\(store.patients.count)", icon: "👥", color: AppColor.secondary)
                        StatCard(label: "Ingresos Hoy", value: Fmt.money(todayRevenue), icon: "💰", color: AppColor.success)
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        Text("Ingresos Mensuales 2025").font(.headline)
                        Chart(revenue) { m in
                            BarMark(x: .value("Mes", m.id), y: .value("Ingresos", m.amount))
                                .foregroundStyle(AppColor.primary.opacity(0.8))
                                .cornerRadius(6)
                        }
                        .chartYAxis {
                            AxisMarks { v in
                                AxisGridLine()
                                AxisValueLabel {
                                    if let d = v.as(Double.self) { Text("$\(Int(d / 1000))k") }
                                }
                            }
                        }
                        .frame(height: 200)
                    }
                    .padding(16).frame(maxWidth: .infinity, alignment: .leading).cardBackground()

                    VStack(alignment: .leading, spacing: 12) {
                        Text("Citas por Estado").font(.headline)
                        ForEach(Catalog.statuses, id: \.self) { s in
                            HStack {
                                Badge(label: s)
                                Spacer()
                                Text("\(store.appointments.filter { $0.status == s }.count)").bold()
                            }
                        }
                    }
                    .padding(16).frame(maxWidth: .infinity, alignment: .leading).cardBackground()

                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Citas de Hoy").font(.headline)
                            Spacer()
                            Button("Ver todas") { store.adminTab = .appointments }
                                .font(.subheadline.weight(.semibold))
                        }
                        if todayApts.isEmpty {
                            Text("Sin citas programadas para hoy")
                                .foregroundStyle(AppColor.textMuted)
                                .frame(maxWidth: .infinity).padding(.vertical, 16)
                        } else {
                            ForEach(todayApts) { a in
                                VStack(alignment: .leading, spacing: 4) {
                                    HStack {
                                        Text(store.patient(a.patientId)?.name ?? "—").font(.subheadline.weight(.semibold))
                                        Spacer()
                                        Badge(label: a.time, color: AppColor.primaryDark, bg: AppColor.primaryLight)
                                    }
                                    HStack {
                                        Text("\(store.treatment(a.treatmentId)?.name ?? "—") · \(a.dentist)")
                                            .font(.footnote).foregroundStyle(AppColor.textMuted)
                                        Spacer()
                                        Badge(label: a.status)
                                    }
                                }
                                Divider()
                            }
                        }
                    }
                    .padding(16).cardBackground()
                }
                .padding(16)
            }
            .screenBackground()
            .navigationTitle("Dashboard")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Text(Fmt.date(today)).font(.footnote).foregroundStyle(AppColor.textMuted)
                }
                ToolbarItem(placement: .topBarTrailing) { UserMenu() }
            }
        }
    }
}
