import SwiftUI

struct ClinicalView: View {
    @EnvironmentObject var store: DataStore
    @State private var path: [String] = []
    @State private var search = ""

    private var filtered: [Patient] {
        search.isEmpty ? store.patients : store.patients.filter { $0.name.lowercased().contains(search.lowercased()) }
    }

    var body: some View {
        NavigationStack(path: $path) {
            List(filtered) { p in
                NavigationLink(value: p.id) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(p.name).font(.headline)
                        Text("\(store.records.filter { $0.patientId == p.id }.count) registros")
                            .font(.caption).foregroundStyle(AppColor.textLight)
                    }
                }
            }
            .searchable(text: $search, prompt: "Buscar paciente")
            .scrollContentBackground(.hidden)
            .screenBackground()
            .navigationTitle("Historial Clínico")
            .toolbar { ToolbarItem(placement: .topBarTrailing) { UserMenu() } }
            .navigationDestination(for: String.self) { id in ClinicalDetailView(patientId: id) }
        }
        .onAppear { consumePending() }
        .onChange(of: store.clinicalPatientId) { _, _ in consumePending() }
    }

    private func consumePending() {
        if let id = store.clinicalPatientId {
            path = [id]
            store.clinicalPatientId = nil
        }
    }
}

struct ClinicalDetailView: View {
    @EnvironmentObject var store: DataStore
    let patientId: String
    @State private var editing: ClinicalRecord?

    var body: some View {
        let recs = store.records.filter { $0.patientId == patientId }.sorted { $0.date > $1.date }
        ScrollView {
            VStack(spacing: 12) {
                if let p = store.patient(patientId) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text(p.name).font(.title3.weight(.heavy))
                        Text("\(p.age) años · \(p.bloodType) · \(p.phone)").font(.footnote).foregroundStyle(AppColor.textMuted)
                        HStack {
                            if p.allergies != "Ninguna" { Badge(label: "⚠ Alergia: \(p.allergies)", color: Color(hex: "856404"), bg: Color(hex: "FFF3CD")) }
                            if p.diseases != "Ninguna" { Badge(label: "🏥 \(p.diseases)", color: Color(hex: "6B21A8"), bg: Color(hex: "F3E8FF")) }
                        }
                    }
                    .padding(16).frame(maxWidth: .infinity, alignment: .leading).cardBackground()
                }
                if recs.isEmpty {
                    EmptyCard(icon: "📋", text: "Sin registros clínicos aún.")
                }
                ForEach(recs) { r in ClinicalRecordCard(record: r, showDentist: true) }
            }
            .padding(16)
        }
        .screenBackground()
        .navigationTitle(store.patient(patientId)?.name ?? "Historial")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    editing = ClinicalRecord(id: DataStore.newId(), patientId: patientId, date: Fmt.todayString, treatment: "",
                                             diagnosis: "", observations: "", prescription: "", dentist: "Dr. González")
                } label: { Label("Nueva entrada", systemImage: "plus") }
            }
        }
        .sheet(item: $editing) { r in ClinicalFormSheet(record: r) }
    }
}

struct ClinicalRecordCard: View {
    let record: ClinicalRecord
    var showDentist: Bool
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(record.treatment).font(.headline)
                Spacer()
                Badge(label: Fmt.date(record.date), color: AppColor.primaryDark, bg: AppColor.primaryLight)
            }
            if showDentist { Text(record.dentist).font(.caption).foregroundStyle(AppColor.textLight) }
            (Text("DIAGNÓSTICO: ").font(.caption.weight(.semibold)).foregroundColor(AppColor.textMuted) + Text(record.diagnosis).font(.subheadline))
            if !record.observations.isEmpty {
                (Text("OBSERVACIONES: ").font(.caption.weight(.semibold)).foregroundColor(AppColor.textMuted) + Text(record.observations).font(.subheadline))
            }
            if !record.prescription.isEmpty {
                (Text("💊 RECETA: ").font(.caption.weight(.semibold)).foregroundColor(AppColor.success) + Text(record.prescription).font(.subheadline))
                    .padding(10).frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(hex: "F0FDF4")).clipShape(RoundedRectangle(cornerRadius: 8))
            }
            if !showDentist { Text("Dentista: \(record.dentist)").font(.caption).foregroundStyle(AppColor.textLight) }
        }
        .padding(16).frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(alignment: .leading) { Rectangle().fill(AppColor.primary).frame(width: 4).clipShape(RoundedRectangle(cornerRadius: 2)) }
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(AppColor.border))
    }
}

struct ClinicalFormSheet: View {
    @EnvironmentObject var store: DataStore
    @Environment(\.dismiss) private var dismiss
    @State var record: ClinicalRecord
    @State private var date = Date()
    @State private var alert: ErrorAlert?

    var body: some View {
        NavigationStack {
            Form {
                TextField("Tratamiento realizado *", text: $record.treatment)
                DatePicker("Fecha", selection: $date, displayedComponents: .date)
                TextField("Dentista", text: $record.dentist)
                TextField("Diagnóstico *", text: $record.diagnosis)
                Section("Observaciones") { TextField("Observaciones", text: $record.observations, axis: .vertical).lineLimit(3...6) }
                Section("Receta médica") { TextField("Receta médica", text: $record.prescription, axis: .vertical).lineLimit(3...6) }
            }
            .navigationTitle("Nueva Entrada Clínica")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Guardar") { save() } }
            }
            .onAppear { date = Fmt.toDate(record.date) }
            .alert(item: $alert) { Alert(title: Text("Atención"), message: Text($0.message)) }
        }
    }

    private func save() {
        if record.treatment.trimmingCharacters(in: .whitespaces).isEmpty || record.diagnosis.trimmingCharacters(in: .whitespaces).isEmpty {
            alert = ErrorAlert(message: "Tratamiento y diagnóstico son obligatorios."); return
        }
        record.date = Fmt.isoFormatter.string(from: date)
        store.records.append(record)
        dismiss()
    }
}
